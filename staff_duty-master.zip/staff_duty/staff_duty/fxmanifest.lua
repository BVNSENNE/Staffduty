fx_version 'cerculean'
games{'gta5'}

author 'Tazio'
description 'staffduty script to display who goes onduty as staff'
version 'v1.0.0'

server_scripts {
  'server.lua'
 }
