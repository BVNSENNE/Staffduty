# staff_duty
A FiveM Plugin

# Installation
1. Download staff_duty!
2. Install it into /resources/<resourceName>
3. setup your aces inside config.lua
4. MAKE SURE YOUR **ACE** PERMISSIONS ARE SETUP CORRECTLY!
5. Have fun!
Note: you have to restart your server to update the principals.

# Permissions
```
add_ace [an role] taz.staff allow
add_principal identifier.steam:[hexid] [an role]
```
Replace the [] with existing thinks!
This is most useful when you have an already existing group(an role)
